/*
proj03.c: project 3 for ARC
autor: NAPISTE SVE JMENO A LOGIN
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <mpi.h>

/* definition of global data functions  - uses NUM_OF_PARTICLES */
#include "globaldata.h"


void usage(char *prog)
{
	fprintf(stderr, "usage : %s filename time_step_size num_of_time_steps\n", prog);
	exit(1);
}

/*
* Funkce abstrahujici implementaci kruhove topologie. Prevzato z MPI_test
*/
int GetSousedVlevo(int ProcID, int ProcCount){
  // -- vrati souseda vlevo --//

  return (ProcID ==0) ?  ProcCount -1 : ProcID -1;
} //-- GetSousedVlevo --//


/*
* Funkce abstrahujici implementaci kruhove topologie. Prevzato z MPI_test
*/
int GetSousedVpravo(int ProcID, int ProcCount){
  //-- vrati souseda vpravo --//
  
  return (ProcID + 1) % ProcCount;  
} //-- GetSousedVpravo --//

// Datovy typ, ktery slouzi pro posilani dat mezi procesy. Staci posilat pouze polohy.
typedef struct
{
	double position [3];
} t_pos;

typedef enum
{
	NO_OVERLAP,
	OVERLAP
} tOverlap;

/*
* Sekvencni reseni. Pouze vytazeno z funkce main. Netreba dalsiho komentare.
*/
void seqSolution(t_particle **part, int num_of_time_steps, double time_step_size)
{
	t_particle *particles = *part;
	int i = 0;
	int p = 0;
	t_particle *pp = NULL;


	pp = alocate_particle_vector();
	memcpy(pp,particles,sizeof(t_particle)*NUM_OF_PARTICLES);


	for (p = 0; p < num_of_time_steps; p++){
		t_particle *pom = NULL;
		pom = pp;
		pp = particles;
		particles = pom;

		for (i=0;i<NUM_OF_PARTICLES; i++) {
			double force0 = 0;
			double force1 = 0;
			double force2 = 0;

			double d0; 
			double d1;
			double d2;

			double f;
			int    j;
			double r;
			double r32;

			for (j=0;j<NUM_OF_PARTICLES;j++){
				d0 = pp[j].position[0]-pp[i].position[0];
				d1 = pp[j].position[1]-pp[i].position[1];	
				d2 = pp[j].position[2]-pp[i].position[2];

				r   = (d0 * d0) + (d1 * d1) + (d2 * d2);
				r32 = pow (r, 1.5);


				if (r != 0){
					f=(GRAVITY*pp[j].weight)/(r32);
					force0 += f*d0;
					force1 += f*d1;
					force2 += f*d2;
				} 	
			}

			particles[i].velocity[0] = pp[i].velocity[0] + (time_step_size * force0);
			particles[i].velocity[1] = pp[i].velocity[1] + (time_step_size * force1);
			particles[i].velocity[2] = pp[i].velocity[2] + (time_step_size * force2);

			particles[i].position[0] = pp[i].position[0] + (time_step_size * particles[i].velocity[0]);
			particles[i].position[1] = pp[i].position[1] + (time_step_size * particles[i].velocity[1]);
			particles[i].position[2] = pp[i].position[2] + (time_step_size * particles[i].velocity[2]);

		}
	}
	free_particle_vector(pp);
	*part = particles;
}

/*
* 1) Komunikace na konci iterace. Prvni bod zadani.
* Vas komentar
*/

void parSolution(t_particle **part, int num_of_time_steps, double time_step_size, int ProcCount, int ProcID)
{

}



/*
* 2) Komunikace b�hem iterace - Implementace paraleln�ho reseni na kruhovo tepologii.
*/
void parSolutionCircle(t_particle **part, int num_of_time_steps, double time_step_size, int ProcCount, int ProcID, int mode)
{

}





int main(int argc, char *argv[]){

	FILE *fp;
	t_particle *particles = NULL;

	double time_step_size;
	int    num_of_time_steps;

	int ProcCount;
	int ProcID;

	// Inicializace MPI
	MPI_Init(&argc,&argv);
	// Zjisteni poctu a Id procesu
	MPI_Comm_size(MPI_COMM_WORLD,&ProcCount);
	MPI_Comm_rank(MPI_COMM_WORLD,&ProcID);

	time_step_size    = 0.0;
	num_of_time_steps = 1;

	particles = alocate_particle_vector();

	if(argc != 4)
		usage(argv[0]);


	time_step_size    = atof(argv[2]);
	num_of_time_steps = atoi(argv[3]);

	// POuze proces nula cte vstup ze souboru.
	if (ProcID == 0)
	{
		if(!(fp=fopen(argv[1], "r")))
		{
			perror(argv[1]);
			exit(1);
		}
		read_particle_vector(fp,particles); 
		//printf("input particles:\n");
		//print_particle_vector(particles);
	}

	// Odkomentovamim spustime pozadovanou funkci. Mela by bezet pouze jedna.

	//parSolution(&particles, num_of_time_steps, time_step_size, ProcCount, ProcID);
	seqSolution(&particles, num_of_time_steps, time_step_size);
	//parSolutionCircle(&particles, num_of_time_steps, time_step_size, ProcCount, ProcID,OVERLAP);
	//parSolutionCircle(&particles, num_of_time_steps, time_step_size, ProcCount, ProcID, NO_OVERLAP);

	// Pouze proces nula tiskne vysledek
	if (ProcID == 0)
	{
		printf("\noutput particles:\n");

		print_particle_vector(particles);

		fclose(fp);
	}


	free_particle_vector(particles);

	// Finalizace MPI
	MPI_Finalize();

	return 0;
}

